#  aws rds DB info

db_host = "database-1.cv4i5qfeypku.ap-northeast-2.rds.amazonaws.com"    #엔드포인트
db_username = "admin"        # 아이디
db_password = "admin123"     # 비번
db_name = "BCDD"
db_port = 3306